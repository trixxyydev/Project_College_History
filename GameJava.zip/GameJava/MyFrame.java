import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyFrame extends JFrame implements ActionListener {
    private JButton restartButton;
    private JButton exitButton;
    private JLabel questionLabel;
    private JButton button1, button2;
    private String[] questions = {
            "Какой столицей является Москва?",
            "Какой город является столицей Франции?",
            "Кто был первым русским дипломатом в первой четверти 20 века?",
            // Добавьте остальные вопросы здесь
            "Кто был первым русским послом в Великобритании в первой четверти 20 века?",
            "Как называлась первая русская женщина-дипломат?",
            "Кто был русским послом в США в первой четверти 20 века?",
            "Кто был русским послом в Германии в первой четверти 20 века?",
            "Кто был русским послом во Франции в первой четверти 20 века?",
            "Кто был русским послом в Австрии-Венгрии в первой четверти 20 века?",
            "Кто был русским послом в Италии в первой четверти 20 века?"
    };
    private String[][] answers = {
            {"Париж", "Москва"},
            {"Берлин", "Париж"},
            {"Алексей Николаевич Щербачев", "Вячеслав Викторович Фон Плеве"},
            // Добавьте остальные ответы здесь
            {"Алексей Александрович Ламсдорф", "Алексей Николаевич Макаров"},
            {"Анна Николаевна Вяземская", "Анна Николаевна Павлова"},
            {"Александр Иванович Извольский", "Сергей Дмитриевич Свербеев"},
            {"Сергей Дмитриевич Свербеев", "Александр Иванович Извольский"},
            {"Павел Александрович Котляревский", "Александр Васильевич Каретников"},
            {"Петр Алексеевич Бакулов", "Петр Павлович Демидов"},
            {"Андрей Иванович Сумароков", "Александр Иванович Макаров"}
    };
    private int questionNumber = 0;
    private int score = 0;
    private Timer timer;
    private int timerDuration = 10; // Длительность таймера в секундах

    public MyFrame() {
        score = 0;

        setTitle("Тест");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        timer = new Timer(timerDuration * 1000, this); // 1 секунда
        timer.setRepeats(false);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 0, 255));
        panel.setLayout(new BorderLayout(30, 30));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        questionLabel = new JLabel(questions[questionNumber]);
        questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 36));
        panel.add(questionLabel, BorderLayout.NORTH);

        JPanel buttonsPanel = new JPanel(new GridLayout(2, 1, 20, 20));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        button1 = createButton(answers[questionNumber][0]);
        buttonsPanel.add(button1);

        button2 = createButton(answers[questionNumber][1]);
        buttonsPanel.add(button2);

        panel.add(buttonsPanel, BorderLayout.CENTER);

        add(panel);

        setExtendedState(JFrame.MAXIMIZED_BOTH); // Установка размеров окна на весь экран
        setUndecorated(true); // Удаление рамки окна

        setVisible(true);

        restartButton = createButton("Заново");
        exitButton = createButton("Выход");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.TRAILING));
        buttonPanel.add(restartButton);
        buttonPanel.add(exitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        restartButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        startGame();
    }


    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(240, 240, 240));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Arial", Font.PLAIN, 24));
        button.setFocusPainted(false);
        button.addActionListener(this);
        return button;
    }

    private void startGame() {
        score = 0;
        questionNumber = 0;

        questionLabel.setText(questions[questionNumber]);
        button1.setText(answers[questionNumber][0]);
        button2.setText(answers[questionNumber][1]);

        button1.setEnabled(true);
        button2.setEnabled(true);
        restartButton.setVisible(false);

        timer.restart();
    }

    public void actionPerformed(ActionEvent e) {
        JButton clickedButton = (JButton) e.getSource();
        String selectedAnswer = clickedButton.getText();
        String correctAnswer = answers[questionNumber][1];

        if (selectedAnswer.equals(correctAnswer)) {
            score++;
        }

        questionNumber++;
        if (questionNumber < questions.length) {
            questionLabel.setText(questions[questionNumber]);
            button1.setText(answers[questionNumber][0]);
            button2.setText(answers[questionNumber][1]);
        } else {
            if (score >= 8) {
                questionLabel.setText("Победа! Вы набрали " + score + " очков.");
            } else {
                questionLabel.setText("Вы проиграли! Попробуйте еще раз.");
                button1.setEnabled(false);
                button2.setEnabled(false);
                restartButton.setVisible(true);
                timer.stop();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new MyFrame();
        });
    }
}